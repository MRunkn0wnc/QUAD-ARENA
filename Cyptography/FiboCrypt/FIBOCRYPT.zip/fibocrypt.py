def fib(n):
    a, b = 0, 1
    seq = []
    for _ in range(n):
        seq.append(a % 26)
        a, b = b, a + b
    return seq

def encrypt(text):
    text = text.lower()
    shifts = fib(len(text))
    enc = []
    for i, c in enumerate(text):
        if c.isalpha():
            shifted = chr((ord(c) - ord('a') + shifts[i]) % 26 + ord('a'))
            enc.append(shifted)
        else:
            enc.append(c)
    return ''.join(enc)

# Encrypt a sample input
flag = "REverseIT"
ciphertext = encrypt(flag)
print(ciphertext)  # REMOVE THIS LINE BEFORE SHARING IF YOU WANT IT TO BE HIDDEN

